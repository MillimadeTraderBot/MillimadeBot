🚀 HOW TO LAUNCH MILLIMADE AI TRADER (Web Version)

1. Go to https://streamlit.io/cloud and sign in with GitHub.
2. Upload this folder to a GitHub repo.
3. Create a new Streamlit app, point to `app.py`.
4. Hit Deploy.

✅ License Key: MILLI-123-KEY